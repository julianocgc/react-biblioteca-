import "./App.css";
import Timer from "./components/Timer";

function App() {
  return (
    <>
      <Timer />
    </>
  );
}

export default App;
