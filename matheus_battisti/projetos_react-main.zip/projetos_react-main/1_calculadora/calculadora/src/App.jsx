
import Calculator from './components/Calculator'
import './App.css'

function App() {

  return (
    <>
      <Calculator />
    </>
  )
}

export default App
