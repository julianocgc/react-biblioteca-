const Error = () => {
  return (
    <div>
      <p>Usuário não encontrado!</p>
    </div>
  );
};

export default Error;
