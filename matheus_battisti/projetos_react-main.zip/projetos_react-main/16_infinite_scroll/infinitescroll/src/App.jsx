import React from "react";
import InfiniteScroll from "./components/InfiniteScroll";

function App() {
  return (
    <div className="App">
      <InfiniteScroll />
    </div>
  );
}

export default App;
