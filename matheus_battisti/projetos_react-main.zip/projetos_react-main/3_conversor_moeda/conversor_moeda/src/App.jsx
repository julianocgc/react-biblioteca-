import "./App.css";
import CurrencyConverter from "./components/CurrencyConverter";

function App() {
  return (
    <>
      <CurrencyConverter />
    </>
  );
}

export default App;
