import { Game } from "./components/Game";

function App() {
  return (
    <div>
      <h1>Jogo da Memória</h1>
      <Game />
    </div>
  );
}

export default App;
