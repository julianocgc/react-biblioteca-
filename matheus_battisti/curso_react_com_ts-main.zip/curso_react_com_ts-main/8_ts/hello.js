console.log("Compilação de TS para JS!");
