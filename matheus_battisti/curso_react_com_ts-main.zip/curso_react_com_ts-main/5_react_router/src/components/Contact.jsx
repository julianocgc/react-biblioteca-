import React from "react";

const Contact = () => {
  return (
    <div>
      <h1>Contato</h1>
      <p>Entre em contato conosco aqui.</p>
    </div>
  );
};

export default Contact;
