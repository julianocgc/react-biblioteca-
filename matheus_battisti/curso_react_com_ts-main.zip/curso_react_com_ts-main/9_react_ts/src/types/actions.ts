export type CounterAction = { type: "increment" } | { type: "decrement" };
