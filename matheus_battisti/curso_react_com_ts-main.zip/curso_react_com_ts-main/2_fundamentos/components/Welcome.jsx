function Welcome(props) {
  return <h1>Olá Mundo!</h1>;
}

export default Welcome;
