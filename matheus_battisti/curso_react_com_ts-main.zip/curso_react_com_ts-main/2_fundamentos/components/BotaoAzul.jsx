function BotaoAzul() {
  return <button className="botao-azul">Clique em mim</button>;
}

export default BotaoAzul;
