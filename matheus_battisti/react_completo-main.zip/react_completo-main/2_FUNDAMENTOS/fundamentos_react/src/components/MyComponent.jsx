const MyComponent = () => {
  return (
    <div>
      <h3>Eu estou em vários componentes!</h3>
    </div>
  );
};

export default MyComponent;
