import MyComponent from "./MyComponent";

// 1 - criando componente
const FirstComponent = () => {
  return (
    <div>
      <h2>Meu primeiro componente!</h2>
      <MyComponent />
    </div>
  );
};

export default FirstComponent;
